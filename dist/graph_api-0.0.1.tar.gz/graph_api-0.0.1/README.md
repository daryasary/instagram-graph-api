# Graph API

Python library to connect [instagram graph API](https://developers.facebook.com/docs/instagram-api) and get data.