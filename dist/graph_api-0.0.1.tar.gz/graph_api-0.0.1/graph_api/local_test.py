from handlers import InstagramAccountsList

access_token = "EAAFn8qH976sBAM92oRGis8zYrKPJpRLZBGLOMx6vlGvRDNLQZC6eGYyu5M2ylcvFvH3TJn7oCj4eGwwfho7hgQ6BeReHMFbzrJAsRSxOiiqiffnfnSA6a17iksEbbNKH9t7q9ywKZAwEBmjhFC5DRizfZCJnTBXCA0mzaCd47E46cK4cj7NsdUfvn7cxtk6I7FUTVNT5RAZDZD"

account_ids = InstagramAccountsList(access_token=access_token)
# print(account_ids.graph.get())

aa = '{"data": [{"instagram_business_account": {"id": "17841403080188510"},"id": "300726913717442"},{"id": "1407571069493691"},{"id": "327701053942657"}],"paging": {"cursors": {"before": "MzAwNzI2OTEzNzE3NDQy","after": "MzI3NzAxMDUzOTQyNjU3"}}}'


def set_pages(response):
    if hasattr(response, 'paging'):
        paging = getattr(response, 'paging')
        cursor = getattr(paging, 'cursors')
        if hasattr(cursor, 'next'):
            _next = getattr(cursor, 'next')
        if hasattr(cursor, 'previous'):
            _previous = getattr(cursor, 'previous')
        if hasattr(response, 'data'):
            _data = getattr(cursor, 'data')
    else:
        _data = response
        _next = None
        _previous = None

    return _previous, _data, _next


print(set_pages(aa))
